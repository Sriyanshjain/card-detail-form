import React from 'react';
import './App.css';
import './css/bootstrap.min.css';
import Creditcard from './components/Creditcard';

function App() {
  return (
    <div className="App">
      <Creditcard/>
    </div>
  );
}

export default App;
